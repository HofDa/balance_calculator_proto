// src/App.tsx
import { AppShell } from '@/app/AppShell';
import { ModuleGrid } from '@/app/ModuleGrid';
import { ImpactSummary } from '@/components/ImpactSummary';
import { useAutoLoadPreset } from '@/app/useAutoLoadPreset';

export default function App() {
  useAutoLoadPreset();

  return (
    <AppShell>
      <div className="space-y-6">
        <ModuleGrid />
        <ImpactSummary />
      </div>
    </AppShell>
  );
}
