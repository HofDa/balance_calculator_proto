// src/store/persist.ts
import type { Module } from '@/engine/types';

const KEY = 'footprint_preset_modules_v1';

export function loadModules(): Module[] | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Module[];
  } catch {
    return null;
  }
}

export function saveModules(modules: Module[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(modules));
  } catch {
    // ignore (private mode etc.)
  }
}
