// src/app/AppShell.tsx
import type { ReactNode } from 'react';
import { TopBar } from '@/app/TopBar';

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopBar />
      <main className="p-6">{children}</main>
    </div>
  );
}
